package com.example.museum3;

import android.app.Activity;
import android.os.Bundle;

public class Museum_Videos extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
	
		super.onCreate(savedInstanceState);
		setContentView(R.layout.museum_video);
	}
	
	

}
